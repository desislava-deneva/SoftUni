import {cats} from './catSeeder.js'

export function getCats(){
    let data = cats;
    return data;
}