import * as api from './api.js';

const endpoints = {
    all: '/data/albums?sortBy=_createdOn%20desc&distinct=name',
    myItems : (userId) => `/data/books?where=_ownerId%3D%22${userId}%22&sortBy=_createdOn%20desc`,
    create: '/data/albums',
    like: '/data/likes',
    byId: '/data/albums/',
    delete: '/data/albums/',
    edit: '/data/albums/'
};



export async function create(data) {
    return api.post(endpoints.create, data);
}

export async function getAll(){
    return api.get(endpoints.all);
}

export async function getById(id) {
    return api.get(endpoints.byId + id);
}

export async function getMyItems(userId) {
    return api.get(endpoints.myItems(userId));
}
export async function createItem(data) {
    return api.post(endpoints.create, data);
}
export async function editItem(id, data) {
    return api.put(endpoints.edit + id, data);
}
export async function deleteItem(id) {
    return api.del(endpoints.delete + id);
}



