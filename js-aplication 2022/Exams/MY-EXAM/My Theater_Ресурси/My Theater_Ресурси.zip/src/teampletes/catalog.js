// import { html } from '../../node_modules/lit-html/lit-html.js'
// // import * as data from '../api/data.js';



// let templeteOne = (game) => html`

// `

// let templeteCatalog = (games) => html`

// `

// export async function catalogPage(ctx, next) {
//     // let allGames = await data.getAll();
//     ctx.render(templeteCatalog());
//     next()
// }

