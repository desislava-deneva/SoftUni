// import { html } from '../../node_modules/lit-html/lit-html.js'
// // import { editById, getById } from '../api/data.js'

// let templeteComments = (comments) => html`
// <ul>
//     ${comments.map(x=> html`<li class="comment"><p>Content: ${x}</p></li>`)}
// </ul>
// `

// function commentsView(ctx) {
//     let comments = await getOwnItem();
//     ctx.render(templeteComments())
// }